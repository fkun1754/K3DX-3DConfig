#!/system/bin/sh
# KDX3D 守护 - Magisk service.sh（开机由 Magisk 执行，独立于 App 进程）
# 功能：确保 FloatBarService 存活（被杀自动拉起）+ OOM 防杀
# 说明：服务常驻但按各应用配置判断是否显示悬浮窗（无配置则不显示，无副作用）
MODDIR=${0%/*}

# 等待系统完全启动（前台服务可正常创建）
sleep 30

# 查找 App 主进程 pid
find_pid() {
    for p in $(ls /proc 2>/dev/null); do
        case $p in
            [0-9]*)
                if grep -q '^com.KDX3D.FKUN$' /proc/$p/cmdline 2>/dev/null; then
                    echo $p
                    return
                fi
                ;;
        esac
    done
}

# 常驻守护循环
while true; do
    pid=$(find_pid)
    if [ -z "$pid" ]; then
        # App 不在运行 → 拉起悬浮窗服务（冷启动进程，开机自启）
        am startservice -n com.KDX3D.FKUN/.FloatBarService 2>/dev/null
    else
        # OOM 防杀（-17 = 不可被 LMK 杀死）
        echo -17 > /proc/$pid/oom_score_adj 2>/dev/null
    fi
    sleep 10
done
