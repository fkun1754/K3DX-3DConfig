#!/system/bin/sh
# KDX3D悬浮条守护 - Magisk service.sh（开机由 Magisk 执行，独立于 App 进程）
# 功能：开关开启时 → 确保 FloatBarService 存活（被杀自动拉起）+ OOM 防杀
MODDIR=${0%/*}

# 等待系统完全启动（前台服务可正常创建）
sleep 30

# 检查开关状态的工具函数
is_enabled() {
    grep -q 'name="enabled" value="true"' \
        /data/data/com.KDX3D.FKUN/shared_prefs/floatbar.xml 2>/dev/null
}

# 查找 App 主进程 pid
find_pid() {
    for p in $(ls /proc 2>/dev/null); do
        case $p in
            [0-9]*)
                if grep -q '^com.KDX3D.FKUN$' /proc/$p/cmdline 2>/dev/null; then
                    echo $p
                    return
                fi
                ;;
        esac
    done
}

# 常驻守护循环
while true; do
    if is_enabled; then
        pid=$(find_pid)
        if [ -z "$pid" ]; then
            # App 不在运行 → 拉起悬浮条服务（冷启动进程）
            am startservice -n com.KDX3D.FKUN/.FloatBarService 2>/dev/null
        else
            # OOM 防杀（-17 = 不可被 LMK 杀死）
            echo -17 > /proc/$pid/oom_score_adj 2>/dev/null
        fi
    fi
    sleep 10
done
